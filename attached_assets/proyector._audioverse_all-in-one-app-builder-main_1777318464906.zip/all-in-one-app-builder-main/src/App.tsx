import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import BookReader from "./components/BookReader.tsx";
import AudioPlayer from "./components/AudioPlayer.tsx";
import MiniAudioPlayer from "./components/MiniAudioPlayer.tsx";
import { AudioPlayerProvider } from "./contexts/AudioPlayerContext.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AudioPlayerProvider>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/read/:id" element={<BookReader />} />
              <Route path="/listen/:id" element={<AudioPlayer />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
            <MiniAudioPlayer />
          </AudioPlayerProvider>
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
