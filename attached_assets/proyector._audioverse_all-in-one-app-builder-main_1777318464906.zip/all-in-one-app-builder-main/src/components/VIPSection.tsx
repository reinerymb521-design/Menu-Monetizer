import { useAuth } from "@/hooks/useAuth";
import { Crown, Sparkles, BookOpen, Shield, Star } from "lucide-react";

export default function VIPSection() {
  const { profile } = useAuth();
  const isPremium = profile?.is_premium;

  if (isPremium) {
    return (
      <div className="space-y-4">
        <div className="glass-panel p-6 text-center space-y-3 premium-glow">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full gradient-vip">
            <Crown className="w-7 h-7 text-black" />
          </div>
          <h2 className="text-xl font-bold">¡Eres VIP! 🎉</h2>
          <p className="text-sm text-muted-foreground">Disfruta de todos los beneficios premium.</p>
          <div className="grid grid-cols-2 gap-3 pt-2">
            {[
              { icon: BookOpen, label: "Biblioteca completa", desc: "Acceso a libros exclusivos" },
              { icon: Shield, label: "Sin anuncios", desc: "Experiencia limpia" },
              { icon: Star, label: "Insignia dorada", desc: "Destaca en la comunidad" },
              { icon: Sparkles, label: "Perfil destacado", desc: "Apareces primero" },
            ].map((b) => (
              <div key={b.label} className="glass-panel p-3 space-y-1">
                <b.icon className="w-5 h-5 mx-auto text-yellow-400" />
                <p className="text-[10px] font-semibold">{b.label}</p>
                <p className="text-[9px] text-muted-foreground">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="glass-panel p-6 text-center space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full gradient-vip">
          <Crown className="w-8 h-8 text-black" />
        </div>
        <h2 className="text-xl font-bold">Carnet Dorado</h2>
        <p className="text-sm text-muted-foreground">Desbloquea la experiencia completa de AudiVerse</p>

        <div className="space-y-3 text-left">
          {[
            { icon: BookOpen, text: "Acceso a toda la biblioteca premium" },
            { icon: Shield, text: "Sin anuncios ni interrupciones" },
            { icon: Star, text: "Insignia dorada en tu perfil" },
            { icon: Sparkles, text: "Apareces destacado en la comunidad" },
          ].map((b, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-yellow-400/10 flex items-center justify-center shrink-0">
                <b.icon className="w-4 h-4 text-yellow-400" />
              </div>
              <p className="text-sm">{b.text}</p>
            </div>
          ))}
        </div>

        <div className="space-y-2 pt-2">
          <button className="w-full py-3 rounded-lg btn-vip text-sm font-bold">
            Mensual — $4.99/mes
          </button>
          <button className="w-full py-3 rounded-lg border border-yellow-400/30 text-yellow-400 text-sm font-medium hover:bg-yellow-400/10 transition">
            Anual — $39.99/año <span className="text-[10px] opacity-70">(ahorra 33%)</span>
          </button>
        </div>
        <p className="text-[10px] text-muted-foreground">Los pagos se activarán próximamente</p>
      </div>
    </div>
  );
}
